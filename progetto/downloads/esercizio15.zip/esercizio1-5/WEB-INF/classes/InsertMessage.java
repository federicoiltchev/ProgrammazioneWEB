import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import jakarta.servlet.annotation.*;
import java.util.*;

@WebServlet("/InsertMessage")
public class InsertMessage extends HttpServlet 
{
	public void init() {}
	
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
	{
		

		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); 
        response.setHeader("Pragma", "no-cache"); 
        response.setHeader("Expires", "0");

		

		HttpSession session = request.getSession(false);

		


		/* Attenzione al return! è necessario altrimenti il resto del codice viene eseguito e sono guai.. */

    	if (session == null) { response.sendRedirect("errore.html"); return; }

		ServletContext ctx = getServletContext();
		ArrayList<String> msgs = (ArrayList<String>) ctx.getAttribute("messages");
        ArrayList<String> owners = (ArrayList<String>) ctx.getAttribute("owners");

		response.setContentType("text/html");
		
		String username = (String) session.getAttribute("username");
		
        if (username == null) { response.sendRedirect("errore.html"); return; }

        String message = (String) request.getParameter("message");

        if (message == null) { response.sendRedirect("errore.html"); return; }

        msgs.add(message);
        owners.add(username);

        ctx.setAttribute("messages", msgs);

        response.sendRedirect("navigation");


	}



}