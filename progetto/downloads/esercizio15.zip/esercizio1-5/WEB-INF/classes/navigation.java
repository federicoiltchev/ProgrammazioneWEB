import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import jakarta.servlet.annotation.*;
import java.util.*;

@WebServlet("/navigation")
public class navigation extends HttpServlet 
{
	
    

	

	public void init()
	{

	}
	
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
	{
		

		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); 
        response.setHeader("Pragma", "no-cache"); 
        response.setHeader("Expires", "0");

		

		HttpSession session = request.getSession(false);

		


		/* Attenzione al return! è necessario altrimenti il resto del codice viene eseguito e sono guai.. */

    	if (session == null) { response.sendRedirect("errore.html"); return; }

		ServletContext ctx = getServletContext();
		ArrayList<String> msgs = (ArrayList<String>) ctx.getAttribute("messages");
		ArrayList<String> owners = (ArrayList<String>) ctx.getAttribute("owners");

		response.setContentType("text/html");
		
		String username = (String) session.getAttribute("username");
		

        PrintWriter out = response.getWriter();
        out.println("<html><body>");

		

		out.println("<h3>Invio messaggi</h3>");
		out.println("<form action='/lez9es4/InsertMessage' method='GET'>");
		out.println("<input type='text' maxlength='200' name='message' placeholder='inserisci qui il tuo messaggio...' required />");
		out.println("<input type='submit' value='inserisci la risposta' />");
		out.println("</form>");


		out.println("<h3>Messaggi inviati</h3>");
		
		out.println("<table>");

		for (int i = 0; i < msgs.size(); i++)
		{
			out.println("<tr>");
			out.println("<td style='border: 1px solid black;'>Da: " + owners.get(i) + "</td>");
			out.println("<td style='border: 1px solid black;'>" + msgs.get(i) + "</td>");
			out.println("</tr>");
		}

		out.println("</table>");


        out.println("</body></html>");

	}



}